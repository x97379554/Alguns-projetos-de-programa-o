# Criação das listas
frutas = []
frutas_doces = []
frutas_nao_doces = []

# Solicita ao usuário os nomes das frutas
for i in range(11):
    fruta = input("Digite o nome de uma fruta: ")
    frutas.append(fruta)

# Classificação das frutas
for fruta in frutas:
    resposta = input(f"A fruta {fruta} é doce? (s/n) ")
    if resposta.lower() == 's':
        frutas_doces.append(fruta)
    else:
        frutas_nao_doces.append(fruta)

# Impressão das listas
print("Frutas doces: ", frutas_doces)
print("Frutas não doces: ", frutas_nao_doces)