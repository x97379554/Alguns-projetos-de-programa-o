import random

# O primeiro jogador escolhe um número entre 0 e 20
numero_secreto = random.randint(0, 20)

# O segundo jogador tem 5 tentativas para adivinhar
for i in range(5):
    palpite = int(input("Digite um número entre 0 e 20: "))
    
    if palpite == numero_secreto:
        print("Acertou!")
        break
    elif abs(palpite - numero_secreto) > 10:
        if palpite > numero_secreto:
            print("MUITO MAIOR")
        else:
            print("MUITO MENOR")
    elif palpite > numero_secreto:
        print("Maior")
    else:
        print("Menor")
else:
    print("As tentativas acabaram. O número era", numero_secreto)
