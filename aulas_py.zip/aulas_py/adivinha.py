# Exercício para casa: 
# Criar um jogo em que o primeiro jogador escolhe um número entre 0 e 20, e o segundo jogador tem que tentar adivinhar. Apenas 5 tentativas.
#   Se o número for maior, o programa escreve ("Maior")
#   Se for menor, ("Menor")
#   Se for igual, (“Acertou!”)

#   Desafio:
#     Se o número for mais que 10 unidades de diferença, escrever "MUITO MAIOR" ou "MUITO MENOR"
#     * Se o número for menor que 3 unidades de diferença, escrever "ESTÁ PRÓXIMO"
#     * Imprimir ao final do jogo quantas tentativas foram usadas para acertar o número

#	Materia avançada:
#     *** Use 'while' para permitir quantas tentativas forem necessárias
#     *** Guarde as tentativas numa 'list' e não permita tentativas repetidas
#     *** Use a biblioteca 'random' para dar uma dica sobre o intervalo onde se encontra o número nas ultimas tentativas

jogador_um = int(input("jogador 1 escolha um numero entre 0 e 20: "))
if not (jogador_um >= 0 and jogador_um <= 20):
	print("Número NÃO está entre 0 e 20")
	exit()


for i in range(1,6):
	jogador_dois = int(input("TENTATIVA "+str(i)+": jogador 2 tente adivinhar o numero do jogador 1: "))
	#  Se o número for maior, o programa escreve ("Maior")
	if  jogador_um > jogador_dois:
		diferenca = jogador_um - jogador_dois
		if diferenca > 10:
			print("MUITO MAIOR")
		else:
			print("MAIOR")
	#  Se for menor, ("Menor")
	elif jogador_um < jogador_dois:
		diferenca = jogador_dois - jogador_um
		if diferenca > 10:
			print("MUITO MENOR")
		else:
			print("MENOR")
	#  Se for igual, (“Acertou!”)
	elif jogador_um == jogador_dois:
		print("IGUAL")
		exit()



