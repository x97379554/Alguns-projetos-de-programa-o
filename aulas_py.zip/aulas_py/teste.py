numeros = [10, 5, 8, 12, 7]

# Adicione o número 15 ao final da lista.
numeros.append(15)

# Remova o segundo elemento da lista.
numeros.pop(1)

# Substitua o Segundo elemento por 20.
numeros[1] = 20

# Encontre e imprima o índice do número 12 na lista.
doze = numeros.index(12)
print("O número 12 na lista é: ", doze)

# Ordene a lista em ordem crescente.
numeros.sort()

# Calcule a soma de todos os elementos da lista.
soma = sum(numeros)
print("A soma  ", soma)
