# 1:
# receba dois numeros inteiros do usuario
# se o primeiro numero for maior que o segundo, imprima o primeiro numero
# se o segundo numero for maior que o primeiro, imprima o segundo numero
# se os dois numeros forem iguais, imprima a mensagem "São iguais"

num1 = int(input("primeiro número int "))
num2 = int(input("segundo número int: "))

if num1 > num2:
    print(num1)
elif num2 > num1:
    print(num2)
else:
    print("São iguais")



# 2:
# uma escola calcula a média do aluno usando a formula: (P1 + P2) / 2
# para passar, o aluno precisa cumprir TODOS esses requisitos:
#	- ter média igual ou superior a 5
#	- ter primeira nota (P1) igual ou superior a 3
#	- ter segunda nota (P2) igual ou superior a 3
# receba dois numeros inteiros do usuario, que representam notas de um aluno
# calcule e imprima a sua média
# imprima se o aluno foi aprovado ou não

nota = int(input(" primeira nota "))
nota2 = int(input("segunda nota "))


media = (nota + nota) / 2

print("A média é ", media)


if media >= 5 and nota >= 3 and nota >= 3:
    print("O aluno foi aprovado.")
else:
    print("O aluno não foi aprovado.")



# 3:
# receba dois numeros inteiros do usuario, que representam o preço de dois produtos distintos
# receba um terceiro numero que representa o dinheiro que o usuario tem
# imprima o que o usuario poderia comprar:
#	- pode comprar os dois
#	- pode comprar qualquer um dos dois, mas apenas um
#	- pode comprar apenas o primeiro
#	- pode comprar apenas o segundo
#	- não pode comprar nenhum
preco1 = int(input(" preço do primeiro produto: "))
preco2 = int(input(" preço do segundo produto: "))

dinheiro = int(input("dinheiro que você tem: "))

if dinheiro >= preco1 + preco2:
    print("comprar os dois produtos")
elif dinheiro >= preco1 and dinheiro >= preco2:
    print("comprar qualquer um dos dois produtos mas apenas um")
elif dinheiro >= preco1:
    print("comprar apenas o primeiro produto ")
elif dinheiro >= preco2:
    print("comprar apenas o segundo produto.")
else:
    print("pode omprar nenhum dos produtos.")

# 4:
# receba 3 numeros inteiros do usuario
# imprima todos eles, em ordem crescente (do menor pro maior)


num1 = int(input("Número 1 "))
num2 = int(input("Número 2 "))
num3 = int(input("Número 3 "))
numeros = [num1, num2, num3]

numeros.sort()

print(numeros)

