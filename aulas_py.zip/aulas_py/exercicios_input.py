# Exercício 1:
# Crie uma variável chamada "nome" e atribua seu nome a ela.
# Em seguida, imprima "Olá, [seu nome]!" na tela.

#Cria uma variável "nome", coloca teu nome nela, depois print um Olá, [teu nome]
nome = "alex "
print("Olá " + nome)

# Exercício 2:
# Peça ao usuário para digitar seu nome usando input e armazene-o em uma variável.
# Em seguida, imprima "Olá, [nome do usuário]!" na tela.

#cria var Pede pro usuário digitar o nome dele usando input, guarda na variável e print um Olá, [nome do usuário]
dig = input("digita seu nome: ")
print("Olá " + dig)

# Exercício 3:
# Crie duas variáveis, "num1" e "num2", e atribua a elas dois números inteiros.
# Realize a soma desses números e imprima o resultado.

#Cria "num1" e "num2", bota dois inteiros neles, soma e mostra o resultado.
num1 = 30
num2 = 30
result = num1 + num2
print("o result = ", result)

# Exercício 4:
# Peça ao usuário para digitar dois números inteiros usando input e armazene-os em variáveis.
# Realize a multiplicação desses números e imprima o resultado.

#2 var input usuário digitar dois inteiros, guarda nas variáveis, multiplica e mostra o resultado.
num1_int = int(input("o primeiro número int "))
num2_int = int(input("o primeiro número int "))
result_int = num1_int * num2_int
print("Result mul ", result_int)

# Exercício 5:
# Crie uma variável chamada "fruta" e atribua o nome de uma fruta a ela.
# Em seguida, crie outra variável chamada "descricao" e atribua uma frase que descreva a fruta usando concatenação de strings.
# Por exemplo, "A [fruta] é uma fruta deliciosa."

#var Cria "fruta", bota nome de uma fruta nela. Depois, var cria "descricao" e descreve a fruta usando concatenação.
fruta = "banana "
descricao = "A " + fruta + "está madura. "
print(descricao)

# Exercício 6:
# Peça ao usuário para digitar o nome de uma fruta usando input e armazene-o em uma variável.
# Em seguida, crie uma frase usando concatenação de strings para descrever a fruta que o usuário digitou.

#var digitar o nome de uma fruta, guarda na variável e descreve usando concatenação.
fruta2 = input("Digite o nome da fruta: ")
descricao2 = "A " + fruta2 + " Já está bastante madura. "
print(descricao2)

# Exercício 7:
# Crie uma variável chamada "texto" e atribua uma frase a ela.
# Em seguida, crie outra variável chamada "repeticao" e atribua um número inteiro.
# Use concatenação de strings para imprimir o "texto" repetido o número de vezes especificado.

# Cria var "texto", bota uma frase nele. Depois, cria "repeticao", bota um número inteiro. Usa concatenação pra imprimir o "texto" repetido o número de vezes.
texto = "A fúria Beserk "
repeticao = 5
print(texto * repeticao)


# Exercício 8:
# Peça ao usuário para digitar uma palavra ou frase usando input e armazene-a em uma variável.
# Em seguida, peça ao usuário para digitar um número inteiro que representa a quantidade de vezes que a palavra ou frase deve ser repetida.
# Use concatenação de strings para imprimir a palavra ou frase repetida o número de vezes especificado pelo usuário.

#var digitar uma palavra ou frase e um número inteiro. Usa concatenação pra imprimir a palavra ou frase repetida o número de vezes.
texto2 = input("Digite sua frase ")
repeticao2 = int(input("dig o número inteiro "))
print(texto2 * repeticao2)


# Exercício 9:
# Crie uma variável chamada "comida" e atribua o nome de um prato de comida a ela.
# Peça ao usuário para digitar um elogio sobre a comida usando input.
# Imprima uma mensagem que inclua a comida e o elogio.

#Cria var "comida", clc nome de um prato nela. Pede pro usuário digitar um elogio sobre a comida. Depois, imprime uma mensagem com a comida e o elogio.
comida = "Miojo "
elogio = input("Digite um elogio para comida ")
print(comida + "É " + elogio +"!!!!!!!!!!")

# Exercício 10:
# Peça ao usuário para digitar seu nome usando input.
# Em seguida, peça ao usuário para digitar uma frase que descreva algo que gostam de fazer.
# Use concatenação de strings para imprimir uma mensagem que inclua o nome do usuário e a frase que descreve suas atividades favoritas.

#vardigitar o nome dele e uma frase que descreve algo que ele gosta de fazer. Depois, imprime uma mensagem com o nome do usuário e a frase.
nome2 = input("Digite seu nome ")
atividade = input("Descreva atividade que você gosta de fazer? ")
messagem = nome2 + atividade
print(messagem)