# 1:
# receba dois numeros inteiros do usuario
# se o primeiro numero for maior que o segundo, imprima o primeiro numero
# se o segundo numero for maior que o primeiro, imprima o segundo numero
# se os dois numeros forem iguais, imprima a mensagem "São iguais"


# 2:
# uma escola calcula a média do aluno usando a formula: (P1 + P2) / 2
# para passar, o aluno precisa cumprir TODOS esses requisitos:
#	- ter média igual ou superior a 5
#	- ter primeira nota (P1) igual ou superior a 3
#	- ter segunda nota (P2) igual ou superior a 3
# receba dois numeros inteiros do usuario, que representam notas de um aluno
# calcule e imprima a sua média
# imprima se o aluno foi aprovado ou não


# 3:
# receba dois numeros inteiros do usuario, que representam o preço de dois produtos distintos
# receba um terceiro numero que representa o dinheiro que o usuario tem
# imprima o que o usuario poderia comprar:
#	- pode comprar os dois
#	- pode comprar qualquer um dos dois, mas apenas um
#	- pode comprar apenas o primeiro
#	- pode comprar apenas o segundo
#	- não pode comprar nenhum

# 4:
# receba 3 numeros inteiros do usuario
# imprima todos eles, em ordem crescente (do menor pro maior)

# Solicita ao usuário que insira dois números inteiros
num1 = int(input("Digite o primeiro número inteiro: "))
num2 = int(input("Digite o segundo número inteiro: "))

# Compara os números e imprime o maior
if num1 > num2:
    print(num1)
elif num2 > num1:
    print(num2)
else:
    print("São iguais")


# Solicita ao usuário que insira duas notas
P1 = float(input("Digite a primeira nota: "))
P2 = float(input("Digite a segunda nota: "))

# Calcula a média
media = (P1 + P2) / 2

# Imprime a média
print("A média é: ", media)

# Verifica se o aluno foi aprovado
if media >= 5 and P1 >= 3 and P2 >= 3:
    print("O aluno foi aprovado.")
else:
    print("O aluno não foi aprovado.")
